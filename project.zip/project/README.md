# multiagent-catch-flag
an experiment for multiagent reinforcement learning with openai multi grid
# python=3.7
# numpy=1.16.0
# gym=0.10.2

uses modded gymmultigrid env

the src directory contains:
/algorithms : our scripts for training and scripts for evaluation and testing
/gym_multigrid: our environment that's built based on https://github.com/ArnaudFickinger/gym-multigrid
from project.ipynb you can run our qlearning models for both adversary and the 2 player team
tensorlog directory contains the tensorboard directory recording our training progress
The recording directory contains recording of our AI performing in the environment

 

